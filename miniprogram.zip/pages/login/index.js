// pages/login/index.js
Page({

  data: {
    userinfo: {}
  },
  onShow() {
    const userinfo = wx.getStorageSync("userinfo");
    this.setData({
      userinfo
    });
  },
  handleGetUserInfo(e) {
    var that = this
    wx.getUserProfile({
      desc: '用于完善会员资料',
      success: (res) => {
        if (res) {
          //用户按了允许授权按钮
          var userInfo = res.userInfo
          wx.setStorageSync('userinfo', userInfo);
          wx.login({
            success: function (res) {
              if (res.code) {
                var appId = 'wxc3d2d8d439e3147a';
                var secret = '2d86051912e08781194a204c54aef73d';
                wx.request({
                  url: 'https://api.weixin.qq.com/sns/jscode2session?appid=' + appId + '&secret=' + secret + '&js_code=' + res.code + '&grant_type=authorization_code',
                  data: {},
                  header: {
                    'content-type': 'json'
                  },
                  success: function (res) {
                    var openid = res.data.openid
                    wx.setStorageSync('openid', openid);
                    //发起API请求
                    wx.request({
                      url: 'https://carbon.zhongkehuiguang.com/api/wechat/user',
                      data: {
                        username: userInfo.nickName,
                        province: userInfo.province,
                        country: userInfo.country,
                        city: userInfo.city,
                        avatarUrl: userInfo.avatarUrl,
                        gender: userInfo.gender,
                        openid: openid
                      },
                      success: function (res) {
                        if (res.data.code == 1) {
                          // 在返回结果中会包含新创建的记录的 _id
                          that.setData({
                            userInfo
                          })
                          wx.showToast({
                            title: '登录成功',
                            duration: 1000,
                            mask: true,
                            success(data) {
                              setTimeout(function () {
                                wx.navigateBack({
                                  delta: 1, // 回退前 delta(默认为1) 页面
                                })
                              }, 1000) //延迟时间
                            }
                          })
                        } else {
                          wx.showToast({
                            title: '登录失败'
                          })
                          console.error('[数据库] [新增记录] 失败：', err)
                        }
                      },
                      fail: function (res) {}
                    })
                  }
                })
              }
            },
          })
        } else {
          //用户按了拒绝按钮
          wx.showModal({
            title: '警告',
            content: '您点击了拒绝授权，将无法进入小程序，请授权之后再进入!',
            showCancel: false,
            confirmText: '返回授权',
            success: function (res) {
              if (res.confirm) {
                console.log('用户点击了返回授权');
              }
            }
          });
        }
      }
    })
  }
})