// pages/index/index.js
const db = wx.cloud.database()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    indicatorDots: true,
    vertical: false,
    autoplay: true,
    interval: 2000,
    duration: 500,
    banner:[],
    classfiy:[],
    raise:[],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    let that = this
    var img_data = 
      [
        {
          "id": 1,
          "imgurl": "/images/1.jpg"
        },
        {
          "id": 2,
          "imgurl": "/images/2.jpg"
        },
        {
          "id": 3,
          "imgurl": "/images/3.jpg"
        }
      ] 
    that.setData({
      banner:img_data
    })
    //发起API请求
    wx.request({
    url: 'https://carbon.zhongkehuiguang.com/api/wechat/customer',
    success: function (res) {
      if (res.data.code == 1) {
        that.setData({
          raise:res.data.data.res
        })
      }
    }
  })
  },
  changeIndicatorDots(e) {
    this.setData({
      indicatorDots: !this.data.indicatorDots
    })
  },
  changeAutoplay(e) {
    this.setData({
      autoplay: !this.data.autoplay
    })
  },
  intervalChange(e) {
    this.setData({
      interval: e.detail.value
    })
  },
  durationChange(e) {
    this.setData({
      duration: e.detail.value
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 点击跳转到领养页面
   */
  adoption:function(){
    wx.navigateTo({
      url: '/pages/adoption/index'
    })
  },
    /**
   * 点击跳转到送养页面
   */
  feeding:function(e){
    wx.navigateTo({
      url: '/pages/feeding/index'
    })
  },
      /**
   * 点击跳转到企业详情
   */
  raise:function(event){
    const id = event.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/raise/index?id='+ id,
    })
  }
})