// // pages/projectDetail/projectDetail.js
Page({
  data: {
    customer:'',
    receive:''
  },
  onLoad: function(options) {
    const that = this
    var id = options.id
    wx.request({
      url: 'https://carbon.zhongkehuiguang.com/api/wechat/customer_id',
      data: {
        id:id
      },
      success: function (res) {
        if (res.data.code == 1) {
          that.setData({
            customer:res.data.data.res,
          })
        }
        if (res.data.data.res.receive == 1) {
          that.setData({
            receive:true,
          })
        }
      }
    })
  },
  submitData(e) {
    const id = e.currentTarget.dataset.id
      const openid = wx.getStorageSync("openid");
      console.log(openid)
        wx.request({
          url: 'https://carbon.zhongkehuiguang.com/api/wechat/receive',
          data: {
            id:id,
            openid:openid
          },
          success: function (res) {
            if (res.data.code == 1) {
              wx.showToast({
                title: '领取成功',
                duration: 1000,
                mask: true,
                success(data) {
                  setTimeout(function () {
                    wx.navigateBack({
                      delta: 1, // 回退前 delta(默认为1) 页面
                    })
                  }, 1000) //延迟时间
                }
              })
            }
          }
        })
  }


  
});